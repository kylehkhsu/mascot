/* Difference betweern transition functions of adaptabs and plainabs */
#include <array>
#include <iostream>
#include <cmath>
#define _USE_MATH_DEFINES
#define numAbs = 3;

using namespace std;

void main() {
    BDD TAdapt[numAbs];
    BDD TPlain[numAbs];
    for(index=0;index<numAbs;index++)   {
        
    }
}
