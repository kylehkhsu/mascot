% Visualize transitions on a 2D plot
 addpath(genpath('../../..'));
%   addpath(genpath('~/ownCloud/C++/SCOTS_modified/mfiles/'));
  addpath(genpath('~/Downloads/SCOTS-master-4d6ebac8e6242b252a3064cead7738bc32834169/mfiles/'));
numAbs = 3;
figure
hold on;
for ii=1:3 
    TAdapt = SymbolicSet(['../unicycle_small_adaptabs/T/T',num2str(ii),'.bdd']);
    pTAdapt = TAdapt.points;
    for jj=1:size(pTAdapt,1)
        annotation('arrow',[pTAdapt(jj,1)/6 pTAdapt(jj,2)/1.8],[pTAdapt(jj,6)/6 pTAdapt(jj,7)/1.8]);
    end
end
figure
hold on
for ii=1:3
    TPlain = SymbolicSet(['../unicycle_small_plainabs/T/T',num2str(ii),'.bdd']);
    pTPlain = TPlain.points;
    for jj=1:size(pTPlain,1)
        annotation('arrow',[pTPlain(jj,1)/6 pTPlain(jj,2)/1.8],[pTPlain(jj,6)/6 pTPlain(jj,7)/1.8]);
    end
end