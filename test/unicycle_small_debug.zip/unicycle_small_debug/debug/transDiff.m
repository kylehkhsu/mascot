% Difference of transition functions of adaptive and plain abstraction
% method
addpath(genpath('../../..'));
%   addpath(genpath('~/ownCloud/C++/SCOTS_modified/mfiles/'));
addpath(genpath('~/Downloads/SCOTS-master-4d6ebac8e6242b252a3064cead7738bc32834169/mfiles/'));
numAbs = 3;
for ii=3:3
    TAdapt = SymbolicSet(['../unicycle_small_adaptabs/T/T',num2str(ii),'.bdd']);
    TPlain = SymbolicSet(['../unicycle_small_plainabs/T/T',num2str(ii),'.bdd']);
    pTAdapt = TAdapt.points;
    pTPlain = TPlain.points;
    Lia = ismember(pTAdapt,pTPlain,'rows');
    if ~all(Lia)
        LiaNeg = ones(size(Lia)) - Lia;
        UnmatchIndex = find(LiaNeg,2)
        MatchIndex = find(Lia,3)
    else
        disp('All elements match');
    end
    pause
end